const cars = [
{
name:"Hyundai Creta",
price:"₹2500/day",
type:"SUV",
image:"https://images.unsplash.com/photo-1503376780353-7e6692767b70"
},

{
name:"Honda City",
price:"₹2200/day",
type:"Sedan",
image:"https://images.unsplash.com/photo-1492144534655-ae79c964c9d7"
},

{
name:"Maruti Swift",
price:"₹1800/day",
type:"Hatchback",
image:"https://images.unsplash.com/photo-1552519507-da3b142c6e3d"
}
];

const container = document.getElementById("carContainer");

function displayCars(data){

container.innerHTML="";

data.forEach(car=>{

container.innerHTML += `
<div class="card">
<img src="${car.image}" alt="${car.name}">
<h3>${car.name}</h3>
<p>${car.price}</p>
<p>${car.type}</p>
<button onclick="bookCar('${car.name}')">
Book Now
</button>
</div>
`;
});
}

function bookCar(name){
alert("Booking Confirmed for " + name);
}

displayCars(cars);

function filterCars(){

const search =
document.getElementById("searchInput")
.value.toLowerCase();

const type =
document.getElementById("filterType")
.value;

const filtered = cars.filter(car=>{

const matchesSearch =
car.name.toLowerCase().includes(search);

const matchesType =
type === "all" || car.type === type;

return matchesSearch && matchesType;
});

displayCars(filtered);
}

document
.getElementById("searchInput")
.addEventListener("keyup",filterCars);

document
.getElementById("filterType")
.addEventListener("change",filterCars);
function submitBooking(){

let name = document.getElementById("name").value;

if(name === ""){
  alert("Please enter your name");
  return;
}

document.getElementById("message").innerHTML =
"✅ Booking Confirmed for " + name;
}